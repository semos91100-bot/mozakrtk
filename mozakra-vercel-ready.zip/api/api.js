const crypto = require('crypto');

const STORE = process.env.SUPABASE_URL;
const SERVICE = process.env.SUPABASE_SERVICE_ROLE_KEY;
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'semos91100@gmail.com').trim().toLowerCase();
const ADMIN_HASH = process.env.ADMIN_PASSWORD_HASH || '';
const JWT_SECRET = process.env.JWT_SECRET || '';
const GEMINI_KEY = process.env.GEMINI_API_KEY || '';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.0-flash';

function send(res, data, status=200){ res.status(status).setHeader('Content-Type','application/json; charset=utf-8').setHeader('Cache-Control','no-store').json(data); }
function body(req){ return req.body && typeof req.body==='object' ? req.body : {}; }
function cleanEmail(e){ return String(e||'').trim().toLowerCase(); }
function validEmail(e){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) && e.length<=190; }
function sign(v){ return crypto.createHmac('sha256',JWT_SECRET).update(v).digest('base64url'); }
function makeCookie(obj){ const p=Buffer.from(JSON.stringify(obj)).toString('base64url'); return `${p}.${sign(p)}`; }
function readCookie(req){ const h=req.headers.cookie||''; const m=h.match(/(?:^|;\s*)mz_auth=([^;]+)/); if(!m||!JWT_SECRET)return null; const [p,s]=m[1].split('.'); if(!p||!s||!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(sign(p))))return null; try{return JSON.parse(Buffer.from(p,'base64url').toString())}catch{return null} }
function setAuth(res,obj){ res.setHeader('Set-Cookie',`mz_auth=${makeCookie(obj)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800`); }
function clearAuth(res){ res.setHeader('Set-Cookie','mz_auth=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'); }
function hashPass(pass){ const [tag,N,r,p,saltB,hashB]=String(ADMIN_HASH).split('$'); if(tag!=='scrypt')return false; const salt=Buffer.from(saltB,'base64url'), expected=Buffer.from(hashB,'base64url'); const got=crypto.scryptSync(pass,salt,expected.length,{N:+N,r:+r,p:+p,maxmem:64*1024*1024}); return crypto.timingSafeEqual(got,expected); }
async function sb(path, options={}){ if(!STORE||!SERVICE) throw new Error('DB_NOT_CONFIGURED'); const r=await fetch(`${STORE}/rest/v1/${path}`,{...options,headers:{apikey:SERVICE,Authorization:`Bearer ${SERVICE}`,'Content-Type':'application/json',...(options.headers||{})}}); const txt=await r.text(); let data=null; try{data=txt?JSON.parse(txt):null}catch{} if(!r.ok) throw new Error(`DB_${r.status}`); return data; }
async function readStore(key, def){ const d=await sb(`app_store?key=eq.${encodeURIComponent(key)}&select=value`); return d&&d[0]&&d[0].value!=null?d[0].value:def; }
async function writeStore(key,value){ await sb('app_store',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:JSON.stringify({key,value})}); return value; }
function adminUser(){return {id:-1,email:ADMIN_EMAIL,name:'Admin',role:'admin',isAdmin:true};}
async function currentUser(req){ const c=readCookie(req); if(!c)return null; if(c.kind==='admin'&&c.email===ADMIN_EMAIL&&hashPass){return adminUser();} if(c.kind==='student'){ const users=await readStore('users',[]); const u=users.find(x=>Number(x.id)===Number(c.uid)); if(u)return {id:Number(u.id),email:u.email,name:u.name||'',role:'student',isAdmin:false,password:u.password,state:u.state||'{}'}; } return null; }
async function requireUser(req,res){ const u=await currentUser(req); if(!u){send(res,{ok:false,error:'AUTH_REQUIRED'},401);return null} return u; }
async function requireAdmin(req,res){ const u=await requireUser(req,res); if(!u)return null; if(!u.isAdmin){send(res,{ok:false,error:'FORBIDDEN'},403);return null} return u; }
function nextId(rows){return rows.reduce((m,x)=>Math.max(m,Number(x.id)||0),0)+1;}
function tooMany(rows,key){const now=Date.now()/1000; return rows.filter(x=>x.k===key&&now-Number(x.t||0)<900).length>=8;}

async function handler(req,res){
 const action=String(req.query.action||''); const method=req.method||'GET';
 try{
  if(!STORE||!SERVICE||!JWT_SECRET){ send(res,{ok:false,error:'SERVER_NOT_CONFIGURED'},500); return; }
  if(action==='me'){
   const u=await currentUser(req); if(!u){send(res,{ok:true,authenticated:false});return}
   send(res,{ok:true,authenticated:true,user:{id:u.id,email:u.email,name:u.name,role:u.role}}); return;
  }
  if(action==='signup'&&method==='POST'){
   const d=body(req), email=cleanEmail(d.email), pass=String(d.password||''), name=String(d.name||'').trim().slice(0,120);
   if(!validEmail(email))return send(res,{ok:false,error:'INVALID_EMAIL'},422); if(pass.length<8)return send(res,{ok:false,error:'PASSWORD_SHORT'},422); if(pass.length>200)return send(res,{ok:false,error:'PASSWORD_LONG'},422);
   const users=await readStore('users',[]); if(email===ADMIN_EMAIL||users.some(u=>cleanEmail(u.email)===email))return send(res,{ok:false,error:'EMAIL_EXISTS'},409);
   const salt=crypto.randomBytes(16).toString('base64url'); const h=crypto.scryptSync(pass,Buffer.from(salt,'base64url'),64,{N:16384,r:8,p:1,maxmem:64*1024*1024}).toString('base64url');
   const id=nextId(users), now=Math.floor(Date.now()/1000); users.push({id,email,password:`scrypt$16384$8$1$${salt}$${h}`,name,state:'{}',created_at:now,updated_at:now}); await writeStore('users',users); setAuth(res,{kind:'student',uid:id}); send(res,{ok:true,authenticated:true,user:{id,email,name,role:'student'}});return;
  }
  if(action==='login'&&method==='POST'){
   const d=body(req), email=cleanEmail(d.email), pass=String(d.password||''); const attempts=await readStore('attempts',[]), key=`login:${email}`;
   if(tooMany(attempts,key))return send(res,{ok:false,error:'TOO_MANY_ATTEMPTS'},429);
   let u=null; if(email===ADMIN_EMAIL&&ADMIN_HASH&&hashPass(pass))u=adminUser(); else {const users=await readStore('users',[]); const x=users.find(z=>cleanEmail(z.email)===email); if(x&&verifyStudent(pass,x.password))u={id:Number(x.id),email:x.email,name:x.name||'',role:'student',isAdmin:false};}
   if(!u){attempts.push({k:key,t:Math.floor(Date.now()/1000)}); await writeStore('attempts',attempts.slice(-5000)); return send(res,{ok:false,error:'LOGIN_FAILED'},401)}
   await writeStore('attempts',attempts.filter(x=>x.k!==key)); setAuth(res,u.isAdmin?{kind:'admin',email:ADMIN_EMAIL}:{kind:'student',uid:u.id}); send(res,{ok:true,authenticated:true,user:{id:u.id,email:u.email,name:u.name,role:u.role}});return;
  }
  if(action==='logout'&&method==='POST'){clearAuth(res);send(res,{ok:true});return;}
  const u=await currentUser(req);
  if(action==='state'&&method==='GET'){
   const uu=await requireUser(req,res); if(!uu)return; if(uu.isAdmin)return send(res,{ok:true,state:[],updated:Math.floor(Date.now()/1000)}); const users=await readStore('users',[]), x=users.find(z=>Number(z.id)===uu.id); let st={};try{st=JSON.parse(x?.state||'{}')}catch{} send(res,{ok:true,state:st,updated:Number(x?.updated_at||0)});return;
  }
  if(action==='state'&&method==='POST'){
   const uu=await requireUser(req,res);if(!uu)return;if(uu.isAdmin)return send(res,{ok:true});const st=body(req).state;if(!st||typeof st!=='object')return send(res,{ok:false,error:'BAD_STATE'},422);const json=JSON.stringify(st);if(json.length>5000000)return send(res,{ok:false,error:'STATE_TOO_LARGE'},413);const users=await readStore('users',[]),x=users.find(z=>Number(z.id)===uu.id);if(!x)return send(res,{ok:false,error:'AUTH_REQUIRED'},401);x.state=json;x.name=String(st.name||x.name||'').slice(0,120);x.updated_at=Math.floor(Date.now()/1000);await writeStore('users',users);send(res,{ok:true,updated:x.updated_at});return;
  }
  if(action==='ai'&&method==='POST'){
   const uu=await requireUser(req,res);if(!uu)return;if(!GEMINI_KEY)return send(res,{ok:false,error:'AI_NOT_CONFIGURED'},503);const d=body(req),messages=Array.isArray(d.messages)?d.messages:[],context=String(d.context||'').slice(0,3000);if(!messages.length)return send(res,{ok:false,error:'EMPTY_MESSAGE'},422);
   const contents=messages.slice(-12).map(m=>({role:m.role==='model'?'model':'user',parts:[{text:String(m.content||'').trim()}]})).filter(x=>x.parts[0].text);const system=`أنت مدرس خصوصي لطالب في الصف الثالث الثانوي (علمي علوم) في مصر. اتكلم بالعامية المصرية البسيطة والمحترمة.\nاشرح بإيجاز وبخطوات، استخدم مثالًا واضحًا، وفي نهاية الرد اسأل سؤال فهم قصير. إذا طلب الطالب اختبارًا أنشئ 5 أسئلة اختيار من متعدد واذكر الإجابات بعد الأسئلة. لا تخترع معلومات خارج المنهج المصري، وإذا لم تكن متأكدًا قل ذلك بوضوح.\nسياق الطالب: ${context}`;
   const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':GEMINI_KEY},body:JSON.stringify({systemInstruction:{parts:[{text:system}]},contents,generationConfig:{temperature:.35,maxOutputTokens:1200}})});const j=await r.json().catch(()=>({}));if(!r.ok)return send(res,{ok:false,error:'AI_PROVIDER'},502);const text=j?.candidates?.[0]?.content?.parts?.[0]?.text||'';if(!text)return send(res,{ok:false,error:'AI_EMPTY'},502);send(res,{ok:true,text});return;
  }
  if(action==='content'&&method==='GET'){send(res,{ok:true,content:await readStore('content',{teachers:[],removed:[]})});return;}
  if(action==='content'&&method==='POST'){
   const aa=await requireAdmin(req,res);if(!aa)return;const d=body(req);if(!Array.isArray(d.teachers)||!Array.isArray(d.removed))return send(res,{ok:false,error:'BAD_CONTENT'},422);const clean=d.teachers.filter(t=>t&&t.id&&t.n&&['fz','km','ah','ar','en'].includes(t.s)).map(t=>({id:String(t.id).slice(0,40),n:String(t.n).slice(0,120),s:t.s,ti:String(t.ti||'').slice(0,20),bio:String(t.bio||'').slice(0,400),links:(Array.isArray(t.links)?t.links:[]).filter(l=>l&&l.k&&l.t&&/^https:\/\//i.test(l.url)).map(l=>({k:String(l.k).slice(0,10),t:String(l.t).slice(0,60),url:String(l.url).slice(0,500)}))}));const removed=[...new Set(d.removed.filter(x=>typeof x==='string'||typeof x==='number').map(String))];await writeStore('content',{teachers:clean,removed});send(res,{ok:true});return;
  }
  if(action==='notifications'&&method==='GET'){const uu=await requireUser(req,res);if(!uu)return;let a=await readStore('notifications',[]);const email=cleanEmail(uu.email);a=a.filter(n=>n.to==='all'||cleanEmail(n.to)===email).sort((x,y)=>(y.created_at||0)-(x.created_at||0)).slice(0,50);send(res,{ok:true,notifications:a});return;}
  if(action==='notifications'&&method==='POST'){const aa=await requireAdmin(req,res);if(!aa)return;const d=body(req),title=String(d.title||'').trim().slice(0,150),bodyText=String(d.body||'').trim().slice(0,1000),to=cleanEmail(d.to||'all');if(!title)return send(res,{ok:false,error:'EMPTY_TITLE'},422);if(to!=='all'&&!validEmail(to))return send(res,{ok:false,error:'INVALID_EMAIL'},422);const a=await readStore('notifications',[]);a.push({id:nextId(a),title,body:bodyText,to,created_at:Math.floor(Date.now()/1000)});await writeStore('notifications',a);send(res,{ok:true});return;}
  if(action==='support'&&method==='GET'){const uu=await requireUser(req,res);if(!uu)return;let a=await readStore('support',[]);if(!uu.isAdmin)a=a.filter(t=>Number(t.uid)===uu.id);a.sort((x,y)=>(y.created_at||0)-(x.created_at||0));send(res,{ok:true,tickets:a,isAdmin:!!uu.isAdmin});return;}
  if(action==='support'&&method==='POST'){const uu=await requireUser(req,res);if(!uu)return;const msg=String(body(req).message||'').trim().slice(0,2000);if(!msg)return send(res,{ok:false,error:'EMPTY_MESSAGE'},422);const a=await readStore('support',[]);a.push({id:nextId(a),uid:uu.id,email:uu.email,name:uu.name,message:msg,reply:null,status:'open',created_at:Math.floor(Date.now()/1000),replied_at:null});await writeStore('support',a);send(res,{ok:true});return;}
  if(action==='support_reply'&&method==='POST'){const aa=await requireAdmin(req,res);if(!aa)return;const id=Number(body(req).id),reply=String(body(req).reply||'').trim().slice(0,2000);if(!id||!reply)return send(res,{ok:false,error:'BAD_REQUEST'},422);const a=await readStore('support',[]);const t=a.find(x=>Number(x.id)===id);if(!t)return send(res,{ok:false,error:'NOT_FOUND'},404);const now=Math.floor(Date.now()/1000);t.reply=reply;t.status='answered';t.replied_at=now;await writeStore('support',a);const n=await readStore('notifications',[]);n.push({id:nextId(n),title:'رد على رسالتك للدعم الفني',body:'المشرف رد على رسالتك، افتح صفحة الدعم الفني عشان تشوف الرد.',to:t.email,created_at:now});await writeStore('notifications',n);send(res,{ok:true});return;}
  send(res,{ok:false,error:'NOT_FOUND'},404);
 }catch(e){ console.error(e); send(res,{ok:false,error:e.message==='DB_NOT_CONFIGURED'?'SERVER_NOT_CONFIGURED':'SERVER_ERROR'},500); }
}
function verifyStudent(pass,stored){try{const [tag,N,r,p,saltB,hashB]=String(stored||'').split('$');if(tag!=='scrypt')return false;const expected=Buffer.from(hashB,'base64url'),got=crypto.scryptSync(pass,Buffer.from(saltB,'base64url'),expected.length,{N:+N,r:+r,p:+p,maxmem:64*1024*1024});return crypto.timingSafeEqual(got,expected)}catch{return false}}
module.exports=handler;
